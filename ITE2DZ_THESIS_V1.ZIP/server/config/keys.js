module.exports = {
    mongoURI: 'mongodb+srv://zus:zus@meme-chat.wicw97u.mongodb.net/?retryWrites=true&w=majority',
    key: '12345678'
}