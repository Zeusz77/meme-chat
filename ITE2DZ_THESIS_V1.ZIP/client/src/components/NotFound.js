

export const NotFound = () => {
    return (
    <div className="text-center mt-5">
        <h1 className="display-1">404 - Not Found!</h1>
    </div>
    );
};

