TODO : 
 - [ ] State presistence on reload
 - [ ] Redux errors empty on login
 - [ ] Message api
 - [ ] doksi 30+ ~40
 - [ ] 