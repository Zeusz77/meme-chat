export const GET_ERRORS = 'GET_ERRORS';
export const SET_CURRENT_USER = 'SET_CURRENT_USER';
export const LOUGOUT_USER = 'LOUGOUT_USER';
export const GET_CHATS = 'GET_CHATS';
export const GET_MESSAGES = 'GET_MESSAGES';
export const ADD_MESSAGE = 'ADD_MESSAGE';
export const GET_TEMPLATES = 'GET_TEMPLATES';